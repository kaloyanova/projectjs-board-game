var NUMBER_OF_COLS = 9;
	NUMBER_OF_ROWS = 7;
	BLOCK_SIZE = 100;

var BLOCK_COLOUR_1 = '#B0C4DE',
	BLOCK_COLOUR_2 = '#D3D3D3',
	HIGHLIGHT_COLOUR = '#fb0006';
    
var piecePositions = null;

var 
	PIECE_ELVE = 3,
	PIECE_KNIGHT = 3,
	PIECE_DWARF = 3,
	IN_PLAY = 0,
	TAKEN = 1,
	pieces = null,
	ctx = null,
	json = null,
	canvas = null,
	BLACK_TEAM = 0,
	RED_TEAM = 1,
	SELECT_LINE_WIDTH = 5,
	currentTurn = RED_TEAM,
	selectedPiece = null;

    function screenToBlock(x, y) {
        var block =  {
            "row": Math.floor(y / BLOCK_SIZE),
            "col": Math.floor(x / BLOCK_SIZE)
        };
    
        return block;
    }

function getPieceAtBlockForTeam(teamOfPieces, clickedBlock) {

	var curPiece = null,
		iPieceCounter = 0,
		pieceAtBlock = null;

	for (iPieceCounter = 0; iPieceCounter < teamOfPieces.length; iPieceCounter++) {

		curPiece = teamOfPieces[iPieceCounter];

		if (curPiece.status === IN_PLAY &&
				curPiece.col === clickedBlock.col &&
				curPiece.row === clickedBlock.row) {
			curPiece.position = iPieceCounter;

			pieceAtBlock = curPiece;
			iPieceCounter = teamOfPieces.length;
		}
	}

	return pieceAtBlock;
}

function blockOccupiedByEnemy(clickedBlock) {
	var team = (currentTurn === BLACK_TEAM ? json.red : json.black);

	return getPieceAtBlockForTeam(team, clickedBlock);
}


function blockOccupied(clickedBlock) {
	var pieceAtBlock = getPieceAtBlockForTeam(json.black, clickedBlock);

	if (pieceAtBlock === null) {
		pieceAtBlock = getPieceAtBlockForTeam(json.red, clickedBlock);
	}

	return (pieceAtBlock !== null);
}

function canPawnMoveToBlock(selectedPiece, clickedBlock, enemyPiece) {
	var iRowToMoveTo = (currentTurn === RED_TEAM ? selectedPiece.row + 1 : selectedPiece.row - 1),
		bAdjacentEnemy = (clickedBlock.col === selectedPiece.col - 1 ||
					clickedBlock.col === selectedPiece.col + 1) &&
					enemyPiece !== null,
		bNextRowEmpty = (clickedBlock.col === selectedPiece.col &&
					blockOccupied(clickedBlock) === false);

	return clickedBlock.row === iRowToMoveTo &&
			(bNextRowEmpty === true || bAdjacentEnemy === true);
}

function canSelectedMoveToBlock(selectedPiece, clickedBlock, enemyPiece) {
	var bCanMove = false;

	switch (selectedPiece.piece) {


	case PIECE_ELVE:
    bCanMove = canPawnMoveToBlock(selectedPiece, clickedBlock, enemyPiece);
		

		break;

	case PIECE_KNIGHT:

    bCanMove = canPawnMoveToBlock(selectedPiece, clickedBlock, enemyPiece);

		break;

	case PIECE_DWARF:

    bCanMove = canPawnMoveToBlock(selectedPiece, clickedBlock, enemyPiece);

		break;

	
	}

	return bCanMove;
}

function getPieceAtBlock(clickedBlock) {

	var team = (currentTurn === BLACK_TEAM ? json.black : json.red);

	return getPieceAtBlockForTeam(team, clickedBlock);
}

function getBlockColour(iRowCounter, iBlockCounter) {
	var cStartColour;
    
	
	if (iRowCounter % 2) {
		cStartColour = (iBlockCounter % 2 ? BLOCK_COLOUR_1 : BLOCK_COLOUR_2);
	} else {
		cStartColour = (iBlockCounter % 2 ? BLOCK_COLOUR_2 : BLOCK_COLOUR_1);
	}
    
    return cStartColour;
    
     
}

function drawBlock(iRowCounter, iBlockCounter) {
	
	ctx.fillStyle = getBlockColour(iRowCounter, iBlockCounter);

	
	ctx.fillRect(iRowCounter * BLOCK_SIZE, iBlockCounter * BLOCK_SIZE,
		BLOCK_SIZE, BLOCK_SIZE);

	ctx.stroke();
}

function getImageCoords(pieceCode, bBlackTeam) {

	var imageCoords =  {
		"x": pieceCode * BLOCK_SIZE,
		"y": (bBlackTeam ? 0 : BLOCK_SIZE)
	};

	return imageCoords;
}

function drawPiece(curPiece, bBlackTeam) {

	var imageCoords = getImageCoords(curPiece.piece, bBlackTeam);

	
	ctx.drawImage(pieces,
		imageCoords.x, imageCoords.y,
		BLOCK_SIZE, BLOCK_SIZE,
		curPiece.col * BLOCK_SIZE, curPiece.row * BLOCK_SIZE,
		BLOCK_SIZE, BLOCK_SIZE);
}

function removeSelection(selectedPiece) {
	drawBlock(selectedPiece.col, selectedPiece.row);
	drawPiece(selectedPiece, (currentTurn === BLACK_TEAM));
}

function drawTeamOfPieces(teamOfPieces, bBlackTeam) {
	var iPieceCounter;

		
	for (iPieceCounter = 0; iPieceCounter < teamOfPieces.length; iPieceCounter++) {
		drawPiece(teamOfPieces[iPieceCounter], bBlackTeam);
	}
}

function drawPieces() {
	drawTeamOfPieces(json.black, true);
	drawTeamOfPieces(json.red, false);
}

function drawRow(iRowCounter) {
	var iBlockCounter;

	
	for (iBlockCounter = 0; iBlockCounter < NUMBER_OF_ROWS; iBlockCounter++) {
		drawBlock(iRowCounter, iBlockCounter);
	}
}

function drawBoard() {
	var iRowCounter;

	for (iRowCounter = 0; iRowCounter < NUMBER_OF_ROWS; iRowCounter++) {
		drawRow(iRowCounter);
	}

	
	ctx.lineWidth = 3;
	ctx.strokeRect(0, 0,
		NUMBER_OF_ROWS * BLOCK_SIZE,
		NUMBER_OF_COLS * BLOCK_SIZE);
}

function defaultPositions() {
	json = {
		"red":
			[
				{
					"piece": PIECE_ELVE,
					"row": 0,
					"col": 1,
                    "status": IN_PLAY,
                    "attack": 5,
                    "bumper": 1,
                    "health": 10,
                    "squardsAttacked":3,
                    "speed": 3

                },
                {
					"piece": PIECE_ELVE,
					"row": 0,
					"col": 3,
                    "status": IN_PLAY,
                    "attack": 5,
                    "bumper": 1,
                    "health": 10,
                    "squardsAttacked":3,
                    "speed": 3
				},
				{
					"piece": PIECE_KNIGHT,
					"row": 0,
					"col": 5,
                    "status": IN_PLAY,
                    "attack": 8,
                    "bumper": 3,
                    "health": 15,
                    "squardsAttacked":1,
                    "speed": 1
                },
                {
					"piece": PIECE_KNIGHT,
					"row": 1,
					"col": 2,
                    "status": IN_PLAY,
                    "attack": 8,
                    "bumper": 3,
                    "health": 15,
                    "squardsAttacked":1,
                    "speed": 1
				},
				{
					"piece": PIECE_DWARF,
					"row": 1,
					"col": 3,
                    "status": IN_PLAY,
                    "attack": 6,
                    "bumper": 2,
                    "health": 12,
                    "squardsAttacked":2,
                    "speed": 2
                },
                {
					"piece": PIECE_DWARF,
					"row": 1,
					"col": 4,
                    "status": IN_PLAY,
                    "attack": 6,
                    "bumper": 2,
                    "health": 12,
                    "squardsAttacked":2,
                    "speed": 2
				}
				
				
				
			],
		"black":
			[
				{
					"piece": PIECE_ELVE,
					"row": 5,
					"col": 2,
                    "status": IN_PLAY,
                    "attack": 5,
                    "bumper": 1,
                    "health": 10,
                    "squardsAttacked":3,
                    "speed": 3
                },
                {
					"piece": PIECE_ELVE,
					"row": 5,
					"col": 3,
                    "status": IN_PLAY,
                    "attack": 5,
                    "bumper": 1,
                    "health": 10,
                    "squardsAttacked":3,
                    "speed": 3
				},
				{
					"piece": PIECE_KNIGHT,
					"row": 5,
					"col": 4,
                    "status": IN_PLAY,
                    "attack": 8,
                    "bumper": 3,
                    "health": 15,
                    "squardsAttacked":1,
                    "speed": 1
                },
                {
					"piece": PIECE_KNIGHT,
					"row": 6,
					"col": 1,
                    "status": IN_PLAY,
                    "attack": 8,
                    "bumper": 3,
                    "health": 15,
                    "squardsAttacked":1,
                    "speed": 1
				},
				{
					"piece": PIECE_DWARF,
					"row": 6,
					"col": 3,
                    "status": IN_PLAY,
                    "attack": 6,
                    "bumper": 2,
                    "health": 12,
                    "squardsAttacked":2,
                    "speed": 2
                },
                {
					"piece": PIECE_DWARF,
					"row": 6,
					"col": 5,
                    "status": IN_PLAY,
                    "attack": 6,
                    "bumper": 2,
                    "health": 12,
                    "squardsAttacked":2,
                    "speed": 2
				}
				
				
			]
	};
}

function selectPiece(pieceAtBlock) {
	
	ctx.lineWidth = SELECT_LINE_WIDTH;
	ctx.strokeStyle = HIGHLIGHT_COLOUR;
	ctx.strokeRect((pieceAtBlock.col * BLOCK_SIZE) + SELECT_LINE_WIDTH,
		(pieceAtBlock.row * BLOCK_SIZE) + SELECT_LINE_WIDTH,
		BLOCK_SIZE - (SELECT_LINE_WIDTH * 2),
		BLOCK_SIZE - (SELECT_LINE_WIDTH * 2 ));

	selectedPiece = pieceAtBlock;
}

function checkIfPieceClicked(clickedBlock) {
	var pieceAtBlock = getPieceAtBlock(clickedBlock);

	if (pieceAtBlock !== null) {
		selectPiece(pieceAtBlock);
	}
}

function movePiece(clickedBlock, enemyPiece) {
	
	drawBlock(selectedPiece.col, selectedPiece.row);

	var team = (currentTurn === RED_TEAM ? json.red : json.black),
		opposite = (currentTurn !== RED_TEAM ? json.red : json.black);

	team[selectedPiece.position].col = clickedBlock.col;
	team[selectedPiece.position].row = clickedBlock.row;

	if (enemyPiece !== null) {
		
		drawBlock(enemyPiece.col, enemyPiece.row);
		opposite[enemyPiece.position].status = TAKEN;
	}

	
	drawPiece(selectedPiece, (currentTurn === BLACK_TEAM));

	currentTurn = (currentTurn === RED_TEAM ? BLACK_TEAM : RED_TEAM);

	selectedPiece = null;
}

function processMove(clickedBlock) {
	var pieceAtBlock = getPieceAtBlock(clickedBlock),
		enemyPiece = blockOccupiedByEnemy(clickedBlock);

	if (pieceAtBlock !== null) {
		removeSelection(selectedPiece);
		checkIfPieceClicked(clickedBlock);
	} else if (canSelectedMoveToBlock(selectedPiece, clickedBlock, enemyPiece) === true) {
		movePiece(clickedBlock, enemyPiece);
	}
}

function board_click(ev) {
	var x = ev.clientX - canvas.offsetLeft,
		y = ev.clientY - canvas.offsetTop,
		clickedBlock = screenToBlock(x, y);

	if (selectedPiece === null) {
		checkIfPieceClicked(clickedBlock);
	} else {
		processMove(clickedBlock);
	}
}

function draw() {
	

	canvas = document.getElementById('game');

	
	if (canvas.getContext) {
		ctx = canvas.getContext('2d');

		BLOCK_SIZE = canvas.height / NUMBER_OF_ROWS;

		drawBoard();

		defaultPositions();

		pieces = new Image();
		pieces.src = 'pictures.png';
		pieces.onload = drawPieces;

		canvas.addEventListener('click', board_click, false);
	} else {
		alert("Canvas problem!");
	}
}